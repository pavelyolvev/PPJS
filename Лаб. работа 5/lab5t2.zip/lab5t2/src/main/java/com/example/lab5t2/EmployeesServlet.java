package com.example.lab5t2;

import com.example.lab5t2.DB.DBconnection;
import com.example.lab5t2.DB.Employees;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@WebServlet("/getEmployees")
public class EmployeesServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws JsonProcessingException, UnsupportedEncodingException {
        String operation = request.getParameter("operation");

        request.setCharacterEncoding("UTF-8");
        List<Employees> employees = new ArrayList<>();
        String num;
        switch (operation){
            case "SelectAll":
                employees = DBconnection.SelectAllQuery();
                break;
            case "DeleteOnNumQuery":
                num = request.getParameter("num");
                DBconnection.DeleteOnNumQuery(Integer.parseInt(num));
                employees = DBconnection.SelectAllQuery();
                break;
            case "SelectOnNum":
                num = request.getParameter("num");
                employees = DBconnection.SelectOnNumQuery(Integer.parseInt(num));
                break;
            case "SelectOnName":
                String name = new String(request.getParameter("name").getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
                employees = DBconnection.SelectOnNameQuery(name);
                //Сделать запрос по имени
            default:
                break;
        }
        response.setContentType("application/json; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        // Преобразуем список в JSON и отправляем его клиенту
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(employees);

        try {
            PrintWriter out = response.getWriter();
            out.println(json);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
